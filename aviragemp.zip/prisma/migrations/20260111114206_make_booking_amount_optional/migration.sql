-- AlterTable
ALTER TABLE "Subscription" ALTER COLUMN "amount" DROP NOT NULL;
