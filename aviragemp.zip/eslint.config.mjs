{
  "extends": ["next/core-web-vitals", "next/typescript"]
}
